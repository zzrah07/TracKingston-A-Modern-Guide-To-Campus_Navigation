import { useState, useEffect, useRef } from "react";

// ─── MOCK DATA ────────────────────────────────────────────────────────────────
const ROUTES = [
  { id: "R1", name: "Route 1 – Northside", color: "#00C9A7", stops: ["Main Gate", "Oak Street", "Park Ave", "Elm Colony", "School"] },
  { id: "R2", name: "Route 2 – Eastside",  color: "#F7B731", stops: ["School", "River Rd", "Pine Block", "Sunrise Apt", "Hill Top"] },
  { id: "R3", name: "Route 3 – Westside",  color: "#FC5C65", stops: ["School", "Lake