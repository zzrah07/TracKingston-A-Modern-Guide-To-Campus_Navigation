import { useState, useEffect, useRef, useCallback } from "react";

/* ═══════════════════════════════════════════════════════════
   MOCK DATA
═══════════════════════════════════════════════════════════ */
const MOCK_USERS = [
  { id: 1, role: "student", name: "Arjun Kumar",    email: "arjun@school.edu",   password: "1234", regNo: "CS2021001", busId: "B01", feeStatus: "pending", feeAmount: 4500, passExpiry: "2025-06-30" },
  { id: 2, role: "teacher", name: "Ms. Priya Nair", email: "priya@school.edu",   password: "1234", empId: "T001",      busId: "B02" },
  { id: 3, role: "driver",  name: "Rajan S.",       email: "rajan@school.edu",   password: "1234", licNo: "TN1234",    busId: "B01" },
  { id: 4, role: "admin",   name: "Admin",          email: "admin@school.edu",   password: "admin" },
];

const MOCK_BUSES = [
  { id: "B01", route: "Route 1 – Northside", driver: "Rajan S.",    driverPhone: "9876543210", capacity: 40, students: 32, status: "moving",  lat: 13.0827, lng: 80.2707, speed: 35, delay: 0 },
  { id: "B02", route: "Route 2 – Eastside",  driver: "Suresh M.",   driverPhone: "9123456780", capacity: 40, students: 28, status: "stopped", lat: 13.0674, lng: 80.2376, speed: 0,  delay: 5 },
  { id: "B03", route: "Route 3 – Westside",  driver: "Kavitha R.",  driverPhone: "9988776655", capacity: 35, students: 30, status: "moving",  lat: 13.0900, lng: 80.2500, speed: 28, delay: 0 },
];

const MOCK_ROUTES = [
  { id: "R1", busId: "B01", name: "Route 1 – Northside", color: "#00C9A7",
    stops: [
      { name: "Main Gate",   lat: 13.0500, lng: 80.2200, eta: "7:10 AM", arrived: true  },
      { name: "Oak Street",  lat: 13.0620, lng: 80.2350, eta: "7:22 AM", arrived: true  },
      { name: "Park Ave",    lat: 13.0720, lng: 80.2500, eta: "7:35 AM", arrived: false },
      { name: "Elm Colony",  lat: 13.0800, lng: 80.2600, eta: "7:48 AM", arrived: false },
      { name: "School",      lat: 13.0827, lng: 80.2707, eta: "8:05 AM", arrived: false },
    ]},
  { id: "R2", busId: "B02", name: "Route 2 – Eastside",  color: "#F7B731",
    stops: [
      { name: "School",      lat: 13.0827, lng: 80.2707, eta: "7:00 AM", arrived: true  },
      { name: "River Rd",    lat: 13.0750, lng: 80.2800, eta: "7:18 AM", arrived: true  },
      { name: "Pine Block",  lat: 13.0680, lng: 80.2900, eta: "7:30 AM", arrived: false },
      { name: "Sunrise Apt", lat: 13.0600, lng: 80.3000, eta: "7:45 AM", arrived: false },
      { name: "Hill Top",    lat: 13.0500, lng: 80.3100, eta: "8:00 AM", arrived: false },
    ]},
  { id: "R3", busId: "B03", name: "Route 3 – Westside",  color: "#FC5C65",
    stops: [
      { name: "Westgate",    lat: 13.0950, lng: 80.2100, eta: "7:05 AM", arrived: true  },
      { name: "Lake View",   lat: 13.0880, lng: 80.2300, eta: "7:20 AM", arrived: false },
      { name: "Sector 7",    lat: 13.0820, lng: 80.2450, eta: "7:35 AM", arrived: false },
      { name: "College Rd",  lat: 13.0827, lng: 80.2600, eta: "7:50 AM", arrived: false },
      { name: "School",      lat: 13.0827, lng: 80.2707, eta: "8:10 AM", arrived: false },
    ]},
];

const MOCK_STUDENTS = [
  { id: 1, name: "Arjun Kumar",   regNo: "CS2021001", busId: "B01", feeStatus: "pending", feeAmount: 4500 },
  { id: 2, name: "Meena Raj",     regNo: "CS2021002", busId: "B01", feeStatus: "paid",    feeAmount: 0    },
  { id: 3, name: "Kiran Babu",    regNo: "EC2021003", busId: "B02", feeStatus: "pending", feeAmount: 3200 },
  { id: 4, name: "Divya Sri",     regNo: "IT2021004", busId: "B03", feeStatus: "paid",    feeAmount: 0    },
  { id: 5, name: "Rohit Das",     regNo: "ME2021005", busId: "B02", feeStatus: "pending", feeAmount: 4500 },
];

const MOCK_NOTIFICATIONS = [
  { id: 1, type: "delay",     msg: "Bus B02 is delayed by 5 minutes on Route 2",       time: "2 min ago",  read: false },
  { id: 2, type: "fee",       msg: "Your transport fee ₹4,500 is due by June 30",       time: "1 hr ago",   read: false },
  { id: 3, type: "geofence",  msg: "Bus B01 has arrived at Oak Street stop",            time: "8 min ago",  read: true  },
  { id: 4, type: "emergency", msg: "🚨 Emergency alert from Bus B03 – Driver Kavitha", time: "Yesterday",  read: true  },
  { id: 5, type: "route",     msg: "Route 1 changed: Park Ave stop removed today",      time: "Yesterday",  read: true  },
];

const ANALYTICS = {
  totalTrips: 482, onTime: 421, delayed: 61,
  avgDelay: "4.2 min", totalStudents: 90, activeDrivers: 3,
  feeCollection: 87200, feePending: 7700,
  busUsage: [
    { bus: "B01", usage: 95 }, { bus: "B02", usage: 88 }, { bus: "B03", usage: 72 },
  ],
};

/* ═══════════════════════════════════════════════════════════
   HELPERS
═══════════════════════════════════════════════════════════ */
function haversine(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return (R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))).toFixed(2);
}

/* ═══════════════════════════════════════════════════════════
   STYLES
═══════════════════════════════════════════════════════════ */
const G = {
  bg:     "#0A0F1E",
  card:   "#111827",
  card2:  "#1a2235",
  border: "#1e2d45",
  blue:   "#2563EB",
  blueL:  "#3b82f6",
  green:  "#10B981",
  greenL: "#34d399",
  yellow: "#F59E0B",
  red:    "#EF4444",
  teal:   "#00C9A7",
  text:   "#F1F5F9",
  muted:  "#64748b",
  font:   "'DM Sans', sans-serif",
  head:   "'Syne', sans-serif",
};

const css = `
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=Syne:wght@600;700;800&display=swap');
* { box-sizing: border-box; margin: 0; padding: 0; }
body { background: ${G.bg}; color: ${G.text}; font-family: ${G.font}; }
::-webkit-scrollbar { width: 4px; } ::-webkit-scrollbar-track { background: ${G.card}; } ::-webkit-scrollbar-thumb { background: ${G.blue}; border-radius: 4px; }
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }
@keyframes slideUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
@keyframes ping { 0%{transform:scale(1);opacity:1} 75%,100%{transform:scale(2);opacity:0} }
@keyframes spin { to{transform:rotate(360deg)} }
@keyframes blink { 0%,100%{box-shadow:0 0 0 0 rgba(16,185,129,.6)} 70%{box-shadow:0 0 0 10px rgba(16,185,129,0)} }
.slide-up { animation: slideUp .4s ease forwards; }
.map-container { width:100%; height:320px; border-radius:16px; overflow:hidden; position:relative; background:#0d1b2a; display:flex; align-items:center; justify-content:center; border:1px solid ${G.border}; }
.map-svg { width:100%; height:100%; }
.bus-dot { animation: blink 1.5s infinite; }
.pulse-ring { animation: ping 1.5s cubic-bezier(0,0,.2,1) infinite; }
.spinner { width:24px;height:24px;border:3px solid ${G.border};border-top-color:${G.blue};border-radius:50%;animation:spin .8s linear infinite; }
`;

/* ═══════════════════════════════════════════════════════════
   MINI SVG MAP COMPONENT
═══════════════════════════════════════════════════════════ */
function SvgMap({ buses, routes, highlightBus, userLat = 13.072, userLng = 80.265 }) {
  const W = 400, H = 300;
  const minLat = 13.045, maxLat = 13.100, minLng = 80.205, maxLng = 80.315;

  const proj = (lat, lng) => ({
    x: ((lng - minLng) / (maxLng - minLng)) * W,
    y: H - ((lat - minLat) / (maxLat - minLat)) * H,
  });

  const userPt = proj(userLat, userLng);

  return (
    <div className="map-container">
      <svg className="map-svg" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
        {/* grid */}
        {[...Array(6)].map((_, i) => (
          <line key={i} x1={i * 80} y1={0} x2={i * 80} y2={H} stroke="#1e2d45" strokeWidth=".5" />
        ))}
        {[...Array(5)].map((_, i) => (
          <line key={i} x1={0} y1={i * 75} x2={W} y2={i * 75} stroke="#1e2d45" strokeWidth=".5" />
        ))}

        {/* roads */}
        {[[13.082,80.21,13.082,80.31],[13.062,80.21,13.062,80.31],[13.072,80.21,13.072,80.31],
          [13.045,80.24,13.100,80.24],[13.045,80.27,13.100,80.27],[13.045,80.30,13.100,80.30]].map(([la1,ln1,la2,ln2], i) => {
          const a = proj(la1, ln1), b = proj(la2, ln2);
          return <line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="#1a2a3a" strokeWidth="6" strokeLinecap="round" />;
        })}

        {/* routes */}
        {routes.map(r => {
          const pts = r.stops.map(s => proj(s.lat, s.lng));
          return (
            <polyline key={r.id}
              points={pts.map(p => `${p.x},${p.y}`).join(" ")}
              fill="none" stroke={r.color} strokeWidth="2" strokeDasharray="4,3" opacity=".7"
            />
          );
        })}

        {/* stops */}
        {routes.flatMap(r => r.stops.map((s, i) => {
          const p = proj(s.lat, s.lng);
          return (
            <g key={`${r.id}-${i}`}>
              <circle cx={p.x} cy={p.y} r="4" fill={r.color} opacity=".8" />
              <circle cx={p.x} cy={p.y} r="2" fill="#fff" />
            </g>
          );
        }))}

        {/* school */}
        {(() => { const p = proj(13.0827, 80.2707); return (
          <g>
            <rect x={p.x-10} y={p.y-10} width="20" height="20" rx="4" fill={G.blue} opacity=".9" />
            <text x={p.x} y={p.y+5} textAnchor="middle" fill="#fff" fontSize="10" fontWeight="bold">S</text>
          </g>
        );})()}

        {/* buses */}
        {buses.map(b => {
          const p = proj(b.lat, b.lng);
          const hi = highlightBus === b.id;
          return (
            <g key={b.id}>
              {b.status === "moving" && (
                <circle cx={p.x} cy={p.y} r="14" fill={G.green} opacity=".15" className="pulse-ring" />
              )}
              <circle cx={p.x} cy={p.y} r="10" fill={hi ? G.yellow : G.green} className={b.status === "moving" ? "bus-dot" : ""} />
              <text x={p.x} y={p.y+4} textAnchor="middle" fill="#000" fontSize="8" fontWeight="bold">{b.id}</text>
            </g>
          );
        })}

        {/* user location */}
        <g>
          <circle cx={userPt.x} cy={userPt.y} r="7" fill={G.blue} opacity=".3" />
          <circle cx={userPt.x} cy={userPt.y} r="4" fill={G.blue} />
          <circle cx={userPt.x} cy={userPt.y} r="2" fill="#fff" />
        </g>
      </svg>

      {/* legend */}
      <div style={{ position:"absolute", bottom:10, left:10, display:"flex", gap:8, flexWrap:"wrap" }}>
        {[{c:G.green,l:"Moving"},{c:G.yellow,l:"Highlighted"},{c:G.blue,l:"You"}].map(({c,l}) => (
          <div key={l} style={{ display:"flex", alignItems:"center", gap:4, background:"rgba(0,0,0,.6)", borderRadius:6, padding:"2px 8px", fontSize:10 }}>
            <span style={{ width:8, height:8, borderRadius:"50%", background:c, display:"inline-block" }} />
            <span style={{ color:"#94a3b8" }}>{l}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   REUSABLE UI COMPONENTS
═══════════════════════════════════════════════════════════ */
const Card = ({ children, style = {} }) => (
  <div style={{ background: G.card, border: `1px solid ${G.border}`, borderRadius: 16, padding: 16, ...style }}>
    {children}
  </div>
);

const Badge = ({ label, color = G.blue, bg }) => (
  <span style={{ background: bg || color + "22", color, border: `1px solid ${color}44`, borderRadius: 20, padding: "2px 10px", fontSize: 11, fontWeight: 600 }}>
    {label}
  </span>
);

const Btn = ({ label, onClick, color = G.blue, icon = "", full = false, small = false, outline = false, danger = false }) => {
  const c = danger ? G.red : color;
  return (
    <button onClick={onClick} style={{
      background: outline ? "transparent" : c,
      color: outline ? c : "#fff",
      border: `2px solid ${c}`,
      borderRadius: 12,
      padding: small ? "6px 14px" : "10px 20px",
      fontFamily: G.font,
      fontWeight: 600,
      fontSize: small ? 12 : 14,
      cursor: "pointer",
      width: full ? "100%" : "auto",
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      transition: "all .2s",
    }}
    onMouseEnter={e => { e.currentTarget.style.opacity = ".85"; }}
    onMouseLeave={e => { e.currentTarget.style.opacity = "1"; }}
    >
      {icon && <span>{icon}</span>}{label}
    </button>
  );
};

const Input = ({ label, type = "text", value, onChange, placeholder }) => (
  <div style={{ marginBottom: 14 }}>
    {label && <div style={{ fontSize: 12, color: G.muted, marginBottom: 6, fontWeight: 600, textTransform: "uppercase", letterSpacing: 1 }}>{label}</div>}
    <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
      style={{
        width: "100%", padding: "11px 14px", background: G.card2, border: `1px solid ${G.border}`,
        borderRadius: 10, color: G.text, fontSize: 14, fontFamily: G.font, outline: "none",
      }}
    />
  </div>
);

const StatCard = ({ label, value, icon, color = G.blue, sub }) => (
  <div style={{ background: G.card2, borderRadius: 14, padding: 16, border: `1px solid ${G.border}`, display:"flex", alignItems:"center", gap:12 }}>
    <div style={{ width: 44, height: 44, borderRadius: 12, background: color + "22", display:"flex", alignItems:"center", justifyContent:"center", fontSize: 22, flexShrink:0 }}>
      {icon}
    </div>
    <div>
      <div style={{ fontSize: 22, fontWeight: 700, color, fontFamily: G.head }}>{value}</div>
      <div style={{ fontSize: 12, color: G.muted }}>{label}</div>
      {sub && <div style={{ fontSize: 11, color: G.muted, marginTop: 2 }}>{sub}</div>}
    </div>
  </div>
);

const NotifIcon = ({ type }) => ({
  delay: "⏰", fee: "💳", geofence: "📍", emergency: "🚨", route: "🔀"
}[type] || "🔔");

const NotifColor = (type) => ({
  delay: G.yellow, fee: G.red, geofence: G.green, emergency: G.red, route: G.blue
}[type] || G.blue);

/* ═══════════════════════════════════════════════════════════
   AUTH SCREEN
═══════════════════════════════════════════════════════════ */
function AuthScreen({ onLogin }) {
  const [tab, setTab] = useState("login");
  const [role, setRole] = useState("student");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [regNo, setRegNo] = useState("");
  const [error, setError] = useState("");

  const handleLogin = () => {
    const u = MOCK_USERS.find(u => u.email === email && u.password === password && u.role === role);
    if (u) onLogin(u);
    else setError("Invalid credentials. Try the demo accounts below.");
  };

  const demoAccounts = [
    { role: "student", email: "arjun@school.edu",  password: "1234",  label: "Student" },
    { role: "teacher", email: "priya@school.edu",  password: "1234",  label: "Teacher" },
    { role: "driver",  email: "rajan@school.edu",  password: "1234",  label: "Driver"  },
    { role: "admin",   email: "admin@school.edu",  password: "admin", label: "Admin"   },
  ];

  return (
    <div style={{ minHeight: "100vh", background: G.bg, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 20 }}>
      <style>{css}</style>

      {/* Logo */}
      <div style={{ textAlign: "center", marginBottom: 32 }} className="slide-up">
        <div style={{ fontSize: 48, marginBottom: 8 }}>🚌</div>
        <div style={{ fontFamily: G.head, fontSize: 28, fontWeight: 800, color: G.text }}>
          Smart<span style={{ color: G.blue }}>Bus</span>
        </div>
        <div style={{ color: G.muted, fontSize: 14 }}>School Transport Tracking System</div>
      </div>

      <div style={{ width: "100%", maxWidth: 400 }} className="slide-up">
        <Card>
          {/* Tabs */}
          <div style={{ display: "flex", gap: 4, background: G.card2, borderRadius: 12, padding: 4, marginBottom: 20 }}>
            {["login", "register"].map(t => (
              <button key={t} onClick={() => setTab(t)} style={{
                flex: 1, padding: "8px", borderRadius: 10, border: "none", cursor: "pointer", fontFamily: G.font,
                fontWeight: 600, fontSize: 13, background: tab === t ? G.blue : "transparent", color: tab === t ? "#fff" : G.muted, transition: "all .2s"
              }}>{t === "login" ? "Sign In" : "Register"}</button>
            ))}
          </div>

          {/* Role Selector */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 6, marginBottom: 20 }}>
            {[
              { r: "student", icon: "👨‍🎓", label: "Student" },
              { r: "teacher", icon: "👩‍🏫", label: "Teacher" },
              { r: "driver",  icon: "🧑‍✈️", label: "Driver"  },
              { r: "admin",   icon: "🧑‍💼", label: "Admin"   },
            ].map(({ r, icon, label }) => (
              <button key={r} onClick={() => setRole(r)} style={{
                padding: "10px 4px", borderRadius: 12, border: `2px solid ${role === r ? G.blue : G.border}`,
                background: role === r ? G.blue + "22" : G.card2, cursor: "pointer", textAlign: "center",
                transition: "all .2s", color: role === r ? G.blue : G.muted
              }}>
                <div style={{ fontSize: 20 }}>{icon}</div>
                <div style={{ fontSize: 10, fontWeight: 600, marginTop: 2, fontFamily: G.font }}>{label}</div>
              </button>
            ))}
          </div>

          {tab === "register" && <Input label="Full Name" value={name} onChange={setName} placeholder="Your full name" />}
          {tab === "register" && role === "student" && <Input label="Register Number" value={regNo} onChange={setRegNo} placeholder="e.g. CS2021001" />}
          <Input label="Email" type="email" value={email} onChange={setEmail} placeholder="your@school.edu" />
          <Input label="Password" type="password" value={password} onChange={setPassword} placeholder="••••••••" />

          {error && <div style={{ color: G.red, fontSize: 12, marginBottom: 12, padding: "8px 12px", background: G.red + "15", borderRadius: 8 }}>{error}</div>}

          <Btn label={tab === "login" ? "Sign In" : "Create Account"} onClick={handleLogin} full color={G.blue} icon="🚀" />

          {/* Demo Accounts */}
          <div style={{ marginTop: 20, borderTop: `1px solid ${G.border}`, paddingTop: 16 }}>
            <div style={{ fontSize: 11, color: G.muted, marginBottom: 10, textAlign: "center", textTransform: "uppercase", letterSpacing: 1 }}>Demo Quick Login</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
              {demoAccounts.map(d => (
                <button key={d.role} onClick={() => { setRole(d.role); setEmail(d.email); setPassword(d.password); setError(""); }}
                  style={{ padding: "6px 8px", borderRadius: 8, border: `1px solid ${G.border}`, background: G.card2, color: G.muted, fontSize: 11, cursor: "pointer", fontFamily: G.font }}>
                  {d.label}
                </button>
              ))}
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   NAV BAR
═══════════════════════════════════════════════════════════ */
function NavBar({ user, onLogout, activeTab, setActiveTab, tabs, notifCount }) {
  const [showNotif, setShowNotif] = useState(false);
  const [notifs, setNotifs] = useState(MOCK_NOTIFICATIONS);

  return (
    <>
      {/* Top Bar */}
      <div style={{ background: G.card, borderBottom: `1px solid ${G.border}`, padding: "12px 16px", display:"flex", alignItems:"center", justifyContent:"space-between", position:"sticky", top:0, zIndex:100 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <span style={{ fontSize:24 }}>🚌</span>
          <div>
            <div style={{ fontFamily: G.head, fontWeight:700, fontSize:16 }}>Smart<span style={{color:G.blue}}>Bus</span></div>
            <div style={{ fontSize:10, color:G.muted }}>{user.role.toUpperCase()}</div>
          </div>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          {/* Notif Bell */}
          <div style={{ position:"relative" }}>
            <button onClick={() => setShowNotif(!showNotif)} style={{ background:"transparent", border:"none", cursor:"pointer", fontSize:20, color:G.text, position:"relative" }}>
              🔔
              {notifs.filter(n=>!n.read).length > 0 && (
                <span style={{ position:"absolute", top:-4, right:-4, width:16, height:16, borderRadius:"50%", background:G.red, fontSize:9, display:"flex", alignItems:"center", justifyContent:"center", color:"#fff", fontWeight:700 }}>
                  {notifs.filter(n=>!n.read).length}
                </span>
              )}
            </button>
          </div>
          <div style={{ width:32, height:32, borderRadius:"50%", background: G.blue+"33", border:`2px solid ${G.blue}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:14, cursor:"pointer" }} onClick={onLogout} title="Logout">
            👤
          </div>
        </div>
      </div>

      {/* Notification Panel */}
      {showNotif && (
        <div style={{ position:"fixed", top:60, right:0, left:0, zIndex:200, background:G.card, borderBottom:`1px solid ${G.border}`, padding:16, maxHeight:360, overflowY:"auto" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 }}>
            <div style={{ fontFamily:G.head, fontWeight:700, fontSize:16 }}>Notifications</div>
            <button onClick={() => { setNotifs(n=>n.map(x=>({...x,read:true}))); setShowNotif(false); }} style={{ fontSize:11, color:G.blue, background:"transparent", border:"none", cursor:"pointer" }}>Mark all read</button>
          </div>
          {notifs.map(n => (
            <div key={n.id} style={{ display:"flex", gap:12, padding:"10px 0", borderBottom:`1px solid ${G.border}30`, opacity: n.read?.5:1 }}>
              <div style={{ width:36, height:36, borderRadius:10, background: NotifColor(n.type)+"22", display:"flex", alignItems:"center", justifyContent:"center", fontSize:18, flexShrink:0 }}>
                <NotifIcon type={n.type} />
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:13, color: n.read ? G.muted : G.text }}>{n.msg}</div>
                <div style={{ fontSize:11, color:G.muted, marginTop:3 }}>{n.time}</div>
              </div>
              {!n.read && <div style={{ width:8, height:8, borderRadius:"50%", background:G.blue, marginTop:6, flexShrink:0 }} />}
            </div>
          ))}
        </div>
      )}

      {/* Bottom Nav */}
      <div style={{ position:"fixed", bottom:0, left:0, right:0, background:G.card, borderTop:`1px solid ${G.border}`, display:"flex", zIndex:100 }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => { setActiveTab(t.id); setShowNotif(false); }} style={{
            flex:1, padding:"10px 4px", background:"transparent", border:"none", cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:3,
            color: activeTab === t.id ? G.blue : G.muted, transition:"color .2s"
          }}>
            <span style={{ fontSize:20 }}>{t.icon}</span>
            <span style={{ fontSize:10, fontWeight:600, fontFamily:G.font }}>{t.label}</span>
          </button>
        ))}
      </div>
    </>
  );
}

/* ═══════════════════════════════════════════════════════════
   STUDENT DASHBOARD
═══════════════════════════════════════════════════════════ */
function StudentDashboard({ user }) {
  const [activeTab, setActiveTab] = useState("home");
  const bus = MOCK_BUSES.find(b => b.id === user.busId);
  const route = MOCK_ROUTES.find(r => r.busId === user.busId);
  const [busesState, setBusesState] = useState(MOCK_BUSES);

  // Simulate bus movement
  useEffect(() => {
    const t = setInterval(() => {
      setBusesState(prev => prev.map(b => b.status === "moving"
        ? { ...b, lat: b.lat + (Math.random() - 0.5) * 0.0005, lng: b.lng + (Math.random() - 0.5) * 0.0005 }
        : b
      ));
    }, 2000);
    return () => clearInterval(t);
  }, []);

  const tabs = [
    { id:"home",   label:"Home",    icon:"🏠" },
    { id:"map",    label:"Track",   icon:"🗺️" },
    { id:"route",  label:"Route",   icon:"📍" },
    { id:"pass",   label:"Pass",    icon:"🎫" },
  ];

  return (
    <div style={{ paddingBottom: 80 }}>
      {activeTab === "home" && (
        <div style={{ padding: 16 }} className="slide-up">
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontFamily: G.head, fontSize: 22, fontWeight: 800 }}>Hello, {user.name.split(" ")[0]} 👋</div>
            <div style={{ color: G.muted, fontSize: 13 }}>Reg No: {user.regNo}</div>
          </div>

          {/* Fee Alert */}
          {user.feeStatus === "pending" && (
            <div style={{ background: G.red+"15", border:`1px solid ${G.red}44`, borderRadius:14, padding:14, marginBottom:16, display:"flex", alignItems:"center", gap:12 }}>
              <span style={{fontSize:24}}>⚠️</span>
              <div>
                <div style={{ fontSize:14, fontWeight:600, color:G.red }}>Transport Fee Due</div>
                <div style={{ fontSize:13, color:G.muted }}>₹{user.feeAmount.toLocaleString()} pending — due Jun 30</div>
              </div>
            </div>
          )}

          {/* Bus Card */}
          <Card style={{ marginBottom: 14 }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 }}>
              <div style={{ fontFamily:G.head, fontWeight:700, fontSize:16 }}>Your Bus</div>
              <Badge label={bus?.status === "moving" ? "🟢 Moving" : "🟡 Stopped"} color={bus?.status === "moving" ? G.green : G.yellow} />
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
              {[
                ["Bus Number", bus?.id],
                ["Route", route?.name.split("–")[0].trim()],
                ["Driver", bus?.driver],
                ["Speed", `${bus?.speed} km/h`],
                ["Distance", `${haversine(13.072, 80.265, bus?.lat, bus?.lng)} km away`],
                ["Delay", bus?.delay > 0 ? `+${bus?.delay} min` : "On time"],
              ].map(([k,v]) => (
                <div key={k} style={{ background:G.card2, borderRadius:10, padding:10 }}>
                  <div style={{ fontSize:10, color:G.muted, textTransform:"uppercase", letterSpacing:.8 }}>{k}</div>
                  <div style={{ fontSize:14, fontWeight:600, marginTop:3, color: k==="Delay" && bus?.delay > 0 ? G.yellow : G.text }}>{v}</div>
                </div>
              ))}
            </div>
            <div style={{ marginTop:12, display:"flex", gap:8 }}>
              <Btn small label="📞 Call Driver" onClick={() => {}} color={G.green} />
              <Btn small outline label="🗺️ Track Live" onClick={() => setActiveTab("map")} />
            </div>
          </Card>

          {/* Next Stop */}
          <Card>
            <div style={{ fontFamily:G.head, fontWeight:700, fontSize:15, marginBottom:12 }}>Next Stops</div>
            {route?.stops.filter(s=>!s.arrived).slice(0,3).map((s,i) => (
              <div key={i} style={{ display:"flex", alignItems:"center", gap:12, padding:"8px 0", borderBottom: i<2 ? `1px solid ${G.border}` : "none" }}>
                <div style={{ width:32, height:32, borderRadius:10, background:G.blue+"22", display:"flex", alignItems:"center", justifyContent:"center", fontSize:14 }}>📍</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:13, fontWeight:600 }}>{s.name}</div>
                  <div style={{ fontSize:11, color:G.muted }}>ETA: {s.eta}</div>
                </div>
                {i === 0 && <Badge label="Next" color={G.green} />}
              </div>
            ))}
          </Card>
        </div>
      )}

      {activeTab === "map" && (
        <div style={{ padding: 16 }} className="slide-up">
          <div style={{ fontFamily:G.head, fontWeight:800, fontSize:20, marginBottom:16 }}>Live Tracking 🗺️</div>
          <SvgMap buses={busesState} routes={MOCK_ROUTES} highlightBus={user.busId} />
          <div style={{ marginTop:14, display:"flex", flexDirection:"column", gap:10 }}>
            {busesState.map(b => (
              <Card key={b.id} style={{ opacity: b.id === user.busId ? 1 : .6 }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <div>
                    <div style={{ fontWeight:700 }}>{b.id} {b.id === user.busId ? "⭐" : ""}</div>
                    <div style={{ fontSize:11, color:G.muted }}>{b.route}</div>
                  </div>
                  <div style={{ textAlign:"right" }}>
                    <Badge label={b.status === "moving" ? "Moving" : "Stopped"} color={b.status === "moving" ? G.green : G.yellow} />
                    <div style={{ fontSize:11, color:G.muted, marginTop:4 }}>{haversine(13.072,80.265,b.lat,b.lng)} km away</div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {activeTab === "route" && (
        <div style={{ padding: 16 }} className="slide-up">
          <div style={{ fontFamily:G.head, fontWeight:800, fontSize:20, marginBottom:16 }}>Route Details 📍</div>
          <Card style={{ marginBottom:14 }}>
            <div style={{ fontFamily:G.head, fontSize:16, fontWeight:700, marginBottom:4 }}>{route?.name}</div>
            <div style={{ color:G.muted, fontSize:12, marginBottom:14 }}>{route?.stops.length} stops · Bus {bus?.id}</div>
            {route?.stops.map((s,i) => (
              <div key={i} style={{ display:"flex", gap:12, marginBottom:8 }}>
                <div style={{ display:"flex", flexDirection:"column", alignItems:"center" }}>
                  <div style={{ width:24, height:24, borderRadius:"50%", background: s.arrived ? G.green : G.border, display:"flex", alignItems:"center", justifyContent:"center", fontSize:11, color:"#fff", fontWeight:700, flexShrink:0 }}>
                    {s.arrived ? "✓" : i+1}
                  </div>
                  {i < route.stops.length-1 && <div style={{ width:2, height:28, background: s.arrived ? G.green+"66" : G.border, marginTop:4 }} />}
                </div>
                <div style={{ flex:1, paddingBottom:8 }}>
                  <div style={{ fontSize:14, fontWeight: s.arrived ? 400 : 600, color: s.arrived ? G.muted : G.text }}>{s.name}</div>
                  <div style={{ fontSize:11, color: s.arrived ? G.green : G.muted }}>{s.arrived ? "✓ Arrived" : `ETA: ${s.eta}`}</div>
                </div>
              </div>
            ))}
          </Card>
        </div>
      )}

      {activeTab === "pass" && (
        <div style={{ padding: 16 }} className="slide-up">
          <div style={{ fontFamily:G.head, fontWeight:800, fontSize:20, marginBottom:16 }}>Bus Pass 🎫</div>
          {/* Pass Card */}
          <div style={{ background:`linear-gradient(135deg, ${G.blue}, #1e40af)`, borderRadius:20, padding:24, marginBottom:16, position:"relative", overflow:"hidden" }}>
            <div style={{ position:"absolute", top:-30, right:-30, width:120, height:120, borderRadius:"50%", background:"rgba(255,255,255,.05)" }} />
            <div style={{ position:"absolute", bottom:-20, left:-20, width:80, height:80, borderRadius:"50%", background:"rgba(255,255,255,.05)" }} />
            <div style={{ fontSize:12, color:"rgba(255,255,255,.7)", textTransform:"uppercase", letterSpacing:2, marginBottom:8 }}>Smart Bus Pass</div>
            <div style={{ fontFamily:G.head, fontSize:22, fontWeight:800, color:"#fff", marginBottom:4 }}>{user.name}</div>
            <div style={{ color:"rgba(255,255,255,.7)", fontSize:13, marginBottom:16 }}>{user.regNo}</div>
            <div style={{ display:"flex", justifyContent:"space-between" }}>
              <div>
                <div style={{ fontSize:11, color:"rgba(255,255,255,.6)" }}>Bus No</div>
                <div style={{ fontSize:18, fontWeight:700, color:"#fff" }}>{user.busId}</div>
              </div>
              <div>
                <div style={{ fontSize:11, color:"rgba(255,255,255,.6)" }}>Valid Until</div>
                <div style={{ fontSize:16, fontWeight:700, color:"#fff" }}>{user.passExpiry}</div>
              </div>
              <div>
                <div style={{ fontSize:11, color:"rgba(255,255,255,.6)" }}>Status</div>
                <div style={{ fontSize:16, fontWeight:700, color: G.green }}>ACTIVE</div>
              </div>
            </div>
          </div>

          {/* Fee Status */}
          <Card>
            <div style={{ fontFamily:G.head, fontWeight:700, fontSize:16, marginBottom:14 }}>Fee Status</div>
            {user.feeStatus === "pending" ? (
              <div>
                <div style={{ display:"flex", justifyContent:"space-between", marginBottom:10 }}>
                  <span style={{ color:G.muted }}>Pending Amount</span>
                  <span style={{ color:G.red, fontWeight:700, fontSize:18 }}>₹{user.feeAmount.toLocaleString()}</span>
                </div>
                <div style={{ height:8, borderRadius:4, background:G.border, marginBottom:12 }}>
                  <div style={{ width:"0%", height:"100%", borderRadius:4, background:G.red }} />
                </div>
                <Btn label="Pay Now" full color={G.blue} icon="💳" onClick={() => alert("Payment gateway integration required")} />
              </div>
            ) : (
              <div style={{ textAlign:"center", padding:"20px 0" }}>
                <div style={{ fontSize:48, marginBottom:8 }}>✅</div>
                <div style={{ fontWeight:700, color:G.green }}>All fees paid</div>
              </div>
            )}
          </Card>
        </div>
      )}

      <NavBar user={{ ...user, role:"student" }} onLogout={() => {}} activeTab={activeTab} setActiveTab={setActiveTab} tabs={tabs} />
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   TEACHER DASHBOARD
═══════════════════════════════════════════════════════════ */
function TeacherDashboard({ user }) {
  const [activeTab, setActiveTab] = useState("home");
  const bus = MOCK_BUSES.find(b => b.id === user.busId);
  const route = MOCK_ROUTES.find(r => r.busId === user.busId);
  const [busesState, setBusesState] = useState(MOCK_BUSES);

  useEffect(() => {
    const t = setInterval(() => {
      setBusesState(prev => prev.map(b => b.status === "moving"
        ? { ...b, lat: b.lat + (Math.random()-.5)*.0005, lng: b.lng + (Math.random()-.5)*.0005 }
        : b));
    }, 2000);
    return () => clearInterval(t);
  }, []);

  const tabs = [
    { id:"home",  label:"Home",  icon:"🏠" },
    { id:"map",   label:"Track", icon:"🗺️" },
    { id:"route", label:"Route", icon:"📍" },
    { id:"notif", label:"Alerts", icon:"🔔" },
  ];

  return (
    <div style={{ paddingBottom: 80 }}>
      {activeTab === "home" && (
        <div style={{ padding: 16 }} className="slide-up">
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontFamily:G.head, fontSize:22, fontWeight:800 }}>Welcome, {user.name.split(" ")[0]} 👩‍🏫</div>
            <div style={{ color:G.muted, fontSize:13 }}>Employee ID: {user.empId}</div>
          </div>

          <Card style={{ marginBottom:14 }}>
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:12 }}>
              <div style={{ fontFamily:G.head, fontWeight:700, fontSize:16 }}>Assigned Bus</div>
              <Badge label={bus?.status === "moving" ? "🟢 Moving" : "🟡 Stopped"} color={bus?.status === "moving" ? G.green : G.yellow} />
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
              {[
                ["Bus", bus?.id], ["Driver", bus?.driver],
                ["Route", route?.name.split("–")[0].trim()], ["Students", `${bus?.students}/${bus?.capacity}`],
                ["Speed", `${bus?.speed} km/h`], ["Delay", bus?.delay > 0 ? `+${bus?.delay} min` : "On time"],
              ].map(([k,v]) => (
                <div key={k} style={{ background:G.card2, borderRadius:10, padding:10 }}>
                  <div style={{ fontSize:10, color:G.muted, textTransform:"uppercase" }}>{k}</div>
                  <div style={{ fontSize:14, fontWeight:600, marginTop:3 }}>{v}</div>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <div style={{ fontFamily:G.head, fontWeight:700, fontSize:15, marginBottom:12 }}>All Buses Status</div>
            {busesState.map(b => (
              <div key={b.id} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"10px 0", borderBottom:`1px solid ${G.border}` }}>
                <div>
                  <div style={{ fontWeight:700, fontSize:14 }}>{b.id} {b.id === user.busId ? "⭐" : ""}</div>
                  <div style={{ fontSize:11, color:G.muted }}>{b.route}</div>
                </div>
                <div style={{ textAlign:"right" }}>
                  <Badge label={b.status === "moving" ? "Moving" : "Stopped"} color={b.status === "moving" ? G.green : G.yellow} />
                  {b.delay > 0 && <div style={{ fontSize:11, color:G.yellow, marginTop:4 }}>+{b.delay} min delay</div>}
                </div>
              </div>
            ))}
          </Card>
        </div>
      )}

      {activeTab === "map" && (
        <div style={{ padding: 16 }} className="slide-up">
          <div style={{ fontFamily:G.head, fontWeight:800, fontSize:20, marginBottom:16 }}>Live Tracking</div>
          <SvgMap buses={busesState} routes={MOCK_ROUTES} highlightBus={user.busId} />
          <div style={{ marginTop:14 }}>
            {busesState.map(b => (
              <Card key={b.id} style={{ marginBottom:10 }}>
                <div style={{ display:"flex", justifyContent:"space-between" }}>
                  <div>
                    <div style={{ fontWeight:700 }}>{b.id} — {b.driver}</div>
                    <div style={{ fontSize:12, color:G.muted }}>{b.route}</div>
                  </div>
                  <div style={{ textAlign:"right" }}>
                    <div style={{ fontSize:13, color: b.status==="moving" ? G.green : G.yellow }}>{b.status}</div>
                    <div style={{ fontSize:11, color:G.muted }}>{b.speed} km/h</div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {activeTab === "route" && (
        <div style={{ padding:16 }} className="slide-up">
          <div style={{ fontFamily:G.head, fontWeight:800, fontSize:20, marginBottom:16 }}>Route Details</div>
          {route?.stops.map((s,i) => (
            <div key={i} style={{ display:"flex", gap:12, marginBottom:8 }}>
              <div style={{ display:"flex", flexDirection:"column", alignItems:"center" }}>
                <div style={{ width:24, height:24, borderRadius:"50%", background: s.arrived ? G.green : G.blue, display:"flex", alignItems:"center", justifyContent:"center", fontSize:11, color:"#fff", fontWeight:700 }}>
                  {s.arrived ? "✓" : i+1}
                </div>
                {i < route.stops.length-1 && <div style={{ width:2, height:28, background:G.border, marginTop:4 }} />}
              </div>
              <div style={{ flex:1, paddingBottom:8 }}>
                <div style={{ fontSize:14, fontWeight: s.arrived ? 400:600, color: s.arrived ? G.muted : G.text }}>{s.name}</div>
                <div style={{ fontSize:11, color: s.arrived ? G.green : G.muted }}>{s.arrived ? "Arrived" : `ETA ${s.eta}`}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === "notif" && (
        <div style={{ padding:16 }} className="slide-up">
          <div style={{ fontFamily:G.head, fontWeight:800, fontSize:20, marginBottom:16 }}>Alerts & Notifications</div>
          {MOCK_NOTIFICATIONS.map(n => (
            <Card key={n.id} style={{ marginBottom:10, opacity: n.read ? .6 : 1 }}>
              <div style={{ display:"flex", gap:12 }}>
                <div style={{ width:40, height:40, borderRadius:12, background:NotifColor(n.type)+"22", display:"flex", alignItems:"center", justifyContent:"center", fontSize:20, flexShrink:0 }}>
                  <NotifIcon type={n.type} />
                </div>
                <div>
                  <div style={{ fontSize:13, fontWeight: n.read ? 400:600 }}>{n.msg}</div>
                  <div style={{ fontSize:11, color:G.muted, marginTop:4 }}>{n.time}</div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <NavBar user={user} onLogout={() => {}} activeTab={activeTab} setActiveTab={setActiveTab} tabs={tabs} />
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   DRIVER DASHBOARD
═══════════════════════════════════════════════════════════ */
function DriverDashboard({ user }) {
  const [activeTab, setActiveTab] = useState("home");
  const [sharing, setSharing] = useState(false);
  const [emergency, setEmergency] = useState(false);
  const [currentStopIdx, setCurrentStopIdx] = useState(1);
  const bus = MOCK_BUSES.find(b => b.id === user.busId);
  const route = MOCK_ROUTES.find(r => r.busId === user.busId);

  const tabs = [
    { id:"home",  label:"Home",  icon:"🏠" },
    { id:"route", label:"Route", icon:"📍" },
    { id:"sos",   label:"SOS",   icon:"🆘" },
  ];

  return (
    <div style={{ paddingBottom: 80 }}>
      {activeTab === "home" && (
        <div style={{ padding: 16 }} className="slide-up">
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontFamily:G.head, fontSize:22, fontWeight:800 }}>Driver Panel 🧑‍✈️</div>
            <div style={{ color:G.muted, fontSize:13 }}>{user.name} · Lic: {user.licNo}</div>
          </div>

          {/* Location Sharing Toggle */}
          <Card style={{ marginBottom:14, background: sharing ? G.green+"15" : G.card, border:`1px solid ${sharing ? G.green : G.border}` }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
              <div>
                <div style={{ fontFamily:G.head, fontWeight:700, fontSize:16 }}>Location Sharing</div>
                <div style={{ fontSize:12, color: sharing ? G.green : G.muted }}>{sharing ? "🟢 Broadcasting live location" : "⚫ Offline"}</div>
              </div>
              <button onClick={() => setSharing(!sharing)} style={{
                width:56, height:28, borderRadius:14, border:"none", cursor:"pointer", position:"relative",
                background: sharing ? G.green : G.border, transition:"all .3s"
              }}>
                <div style={{ width:22, height:22, borderRadius:"50%", background:"#fff", position:"absolute", top:3, left: sharing ? 31 : 3, transition:"all .3s" }} />
              </button>
            </div>
          </Card>

          {/* Bus Info */}
          <Card style={{ marginBottom:14 }}>
            <div style={{ fontFamily:G.head, fontWeight:700, fontSize:15, marginBottom:12 }}>Today's Assignment</div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
              {[
                ["Bus", bus?.id], ["Capacity", bus?.capacity],
                ["Students", bus?.students], ["Route", route?.name.split("–")[0].trim()],
              ].map(([k,v]) => (
                <div key={k} style={{ background:G.card2, borderRadius:10, padding:10 }}>
                  <div style={{ fontSize:10, color:G.muted, textTransform:"uppercase" }}>{k}</div>
                  <div style={{ fontSize:16, fontWeight:700, marginTop:3 }}>{v}</div>
                </div>
              ))}
            </div>
          </Card>

          {/* Next Stop */}
          <Card>
            <div style={{ fontFamily:G.head, fontWeight:700, fontSize:15, marginBottom:12 }}>Stop Progress</div>
            <div style={{ marginBottom:12 }}>
              <div style={{ display:"flex", justifyContent:"space-between", fontSize:12, color:G.muted, marginBottom:6 }}>
                <span>Completed</span><span>{currentStopIdx}/{route?.stops.length} stops</span>
              </div>
              <div style={{ height:8, borderRadius:4, background:G.border }}>
                <div style={{ width:`${(currentStopIdx/route?.stops.length)*100}%`, height:"100%", borderRadius:4, background:G.green, transition:"width .5s" }} />
              </div>
            </div>
            {route?.stops[currentStopIdx] && (
              <div style={{ background:G.card2, borderRadius:12, padding:12, marginBottom:12 }}>
                <div style={{ fontSize:11, color:G.muted, marginBottom:4 }}>NEXT STOP</div>
                <div style={{ fontSize:18, fontWeight:700 }}>{route.stops[currentStopIdx].name}</div>
                <div style={{ fontSize:13, color:G.blue }}>ETA: {route.stops[currentStopIdx].eta}</div>
              </div>
            )}
            <Btn label="✅ Mark Stop Arrived" full color={G.green} onClick={() => setCurrentStopIdx(i => Math.min(i+1, route.stops.length-1))} />
          </Card>
        </div>
      )}

      {activeTab === "route" && (
        <div style={{ padding:16 }} className="slide-up">
          <div style={{ fontFamily:G.head, fontWeight:800, fontSize:20, marginBottom:16 }}>My Route</div>
          <Card style={{ marginBottom:14 }}>
            <div style={{ fontFamily:G.head, fontSize:15, fontWeight:700, marginBottom:12 }}>{route?.name}</div>
            {route?.stops.map((s,i) => (
              <div key={i} style={{ display:"flex", gap:12, marginBottom:8 }}>
                <div style={{ display:"flex", flexDirection:"column", alignItems:"center" }}>
                  <div style={{ width:28, height:28, borderRadius:"50%", background: i < currentStopIdx ? G.green : i === currentStopIdx ? G.blue : G.border, display:"flex", alignItems:"center", justifyContent:"center", fontSize:12, color:"#fff", fontWeight:700, flexShrink:0 }}>
                    {i < currentStopIdx ? "✓" : i+1}
                  </div>
                  {i < route.stops.length-1 && <div style={{ width:2, height:28, background: i < currentStopIdx ? G.green+"66" : G.border, marginTop:4 }} />}
                </div>
                <div style={{ flex:1, paddingBottom:8 }}>
                  <div style={{ fontSize:14, fontWeight: i === currentStopIdx ? 700:400, color: i < currentStopIdx ? G.muted : G.text }}>
                    {s.name} {i === currentStopIdx && <Badge label="Current" color={G.blue} />}
                  </div>
                  <div style={{ fontSize:11, color:G.muted }}>{s.eta}</div>
                </div>
              </div>
            ))}
          </Card>
        </div>
      )}

      {activeTab === "sos" && (
        <div style={{ padding:16, textAlign:"center" }} className="slide-up">
          <div style={{ fontFamily:G.head, fontWeight:800, fontSize:20, marginBottom:8 }}>Emergency Panel</div>
          <div style={{ color:G.muted, fontSize:13, marginBottom:32 }}>Press the SOS button only in emergencies. Admin and school will be notified immediately.</div>

          {/* Big SOS Button */}
          <div style={{ position:"relative", display:"inline-block", marginBottom:40 }}>
            {emergency && (
              <>
                <div style={{ position:"absolute", inset:-20, borderRadius:"50%", background:G.red+"22", animation:"ping 1s ease-out infinite" }} />
                <div style={{ position:"absolute", inset:-10, borderRadius:"50%", background:G.red+"33", animation:"ping 1.5s ease-out infinite" }} />
              </>
            )}
            <button onClick={() => setEmergency(!emergency)} style={{
              width:160, height:160, borderRadius:"50%", border:`6px solid ${G.red}`,
              background: emergency ? G.red : G.red+"22",
              color: emergency ? "#fff" : G.red,
              fontSize:emergency ? 28 : 48,
              fontWeight:800, fontFamily:G.head, cursor:"pointer",
              boxShadow: emergency ? `0 0 40px ${G.red}88` : "none",
              transition:"all .3s",
            }}>
              {emergency ? "🚨 SOS\nSENT" : "🆘"}
            </button>
          </div>

          {emergency && (
            <Card style={{ background:G.red+"15", border:`1px solid ${G.red}44`, textAlign:"left" }}>
              <div style={{ color:G.red, fontWeight:700, marginBottom:8 }}>🚨 Emergency Alert Active</div>
              <div style={{ fontSize:13, color:G.muted }}>Admin has been notified. Help is on the way. Stay calm and keep students safe.</div>
              <div style={{ marginTop:12 }}>
                <Btn small label="✅ Cancel Emergency" onClick={() => setEmergency(false)} color={G.green} />
              </div>
            </Card>
          )}

          <div style={{ marginTop:24, display:"grid", gap:10 }}>
            {[["📞 Call Admin","9000000001"],["🏫 Call School","9000000002"],["🚔 Call Police","100"]].map(([l,n]) => (
              <Card key={l} style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <span style={{ fontSize:14, fontWeight:600 }}>{l}</span>
                <Badge label={n} color={G.blue} />
              </Card>
            ))}
          </div>
        </div>
      )}

      <NavBar user={user} onLogout={() => {}} activeTab={activeTab} setActiveTab={setActiveTab} tabs={tabs} />
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   ADMIN DASHBOARD
═══════════════════════════════════════════════════════════ */
function AdminDashboard({ user }) {
  const [activeTab, setActiveTab] = useState("home");
  const [busesState, setBusesState] = useState(MOCK_BUSES);
  const [searchQ, setSearchQ] = useState("");

  useEffect(() => {
    const t = setInterval(() => {
      setBusesState(prev => prev.map(b => b.status === "moving"
        ? { ...b, lat: b.lat + (Math.random()-.5)*.0005, lng: b.lng + (Math.random()-.5)*.0005 }
        : b));
    }, 2000);
    return () => clearInterval(t);
  }, []);

  const tabs = [
    { id:"home",     label:"Overview", icon:"📊" },
    { id:"buses",    label:"Buses",    icon:"🚌" },
    { id:"students", label:"Students", icon:"👥" },
    { id:"reports",  label:"Reports",  icon:"📄" },
  ];

  const filteredStudents = MOCK_STUDENTS.filter(s =>
    s.name.toLowerCase().includes(searchQ.toLowerCase()) || s.regNo.toLowerCase().includes(searchQ.toLowerCase())
  );

  return (
    <div style={{ paddingBottom: 80 }}>
      {activeTab === "home" && (
        <div style={{ padding:16 }} className="slide-up">
          <div style={{ marginBottom:16 }}>
            <div style={{ fontFamily:G.head, fontSize:22, fontWeight:800 }}>Admin Dashboard 🧑‍💼</div>
            <div style={{ color:G.muted, fontSize:13 }}>Overview · {new Date().toDateString()}</div>
          </div>

          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:14 }}>
            <StatCard label="Total Students" value={ANALYTICS.totalStudents} icon="👥" color={G.blue} />
            <StatCard label="Active Buses" value={ANALYTICS.activeDrivers} icon="🚌" color={G.green} />
            <StatCard label="On-Time Trips" value={ANALYTICS.onTime} icon="✅" color={G.green} sub={`of ${ANALYTICS.totalTrips} total`} />
            <StatCard label="Delayed Trips" value={ANALYTICS.delayed} icon="⏰" color={G.yellow} sub={`Avg ${ANALYTICS.avgDelay}`} />
          </div>

          {/* Fee Overview */}
          <Card style={{ marginBottom:14 }}>
            <div style={{ fontFamily:G.head, fontWeight:700, fontSize:15, marginBottom:12 }}>Fee Collection</div>
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:8 }}>
              <span style={{ color:G.muted }}>Collected</span>
              <span style={{ color:G.green, fontWeight:700 }}>₹{ANALYTICS.feeCollection.toLocaleString()}</span>
            </div>
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:12 }}>
              <span style={{ color:G.muted }}>Pending</span>
              <span style={{ color:G.red, fontWeight:700 }}>₹{ANALYTICS.feePending.toLocaleString()}</span>
            </div>
            <div style={{ height:8, borderRadius:4, background:G.border }}>
              <div style={{ width:`${(ANALYTICS.feeCollection/(ANALYTICS.feeCollection+ANALYTICS.feePending))*100}%`, height:"100%", borderRadius:4, background:G.green }} />
            </div>
            <div style={{ fontSize:11, color:G.muted, marginTop:6, textAlign:"right" }}>
              {Math.round((ANALYTICS.feeCollection/(ANALYTICS.feeCollection+ANALYTICS.feePending))*100)}% collected
            </div>
          </Card>

          {/* Bus Usage */}
          <Card style={{ marginBottom:14 }}>
            <div style={{ fontFamily:G.head, fontWeight:700, fontSize:15, marginBottom:12 }}>Bus Utilization</div>
            {ANALYTICS.busUsage.map(b => (
              <div key={b.bus} style={{ marginBottom:12 }}>
                <div style={{ display:"flex", justifyContent:"space-between", fontSize:13, marginBottom:6 }}>
                  <span style={{ fontWeight:600 }}>{b.bus}</span><span style={{ color:G.muted }}>{b.usage}%</span>
                </div>
                <div style={{ height:8, borderRadius:4, background:G.border }}>
                  <div style={{ width:`${b.usage}%`, height:"100%", borderRadius:4, background: b.usage>90 ? G.red : b.usage>75 ? G.yellow : G.green, transition:"width .5s" }} />
                </div>
              </div>
            ))}
          </Card>

          {/* Live Map */}
          <div style={{ fontFamily:G.head, fontWeight:700, fontSize:15, marginBottom:10 }}>Live Fleet Map</div>
          <SvgMap buses={busesState} routes={MOCK_ROUTES} />
        </div>
      )}

      {activeTab === "buses" && (
        <div style={{ padding:16 }} className="slide-up">
          <div style={{ fontFamily:G.head, fontWeight:800, fontSize:20, marginBottom:16 }}>Fleet Management 🚌</div>
          {busesState.map(b => {
            const route = MOCK_ROUTES.find(r => r.busId === b.id);
            return (
              <Card key={b.id} style={{ marginBottom:12 }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 }}>
                  <div>
                    <div style={{ fontFamily:G.head, fontWeight:700, fontSize:18 }}>{b.id}</div>
                    <div style={{ fontSize:12, color:G.muted }}>{b.route}</div>
                  </div>
                  <Badge label={b.status === "moving" ? "🟢 Moving" : "🟡 Stopped"} color={b.status === "moving" ? G.green : G.yellow} />
                </div>
                <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:8, marginBottom:12 }}>
                  {[["Driver",b.driver.split(" ")[0]],["Students",`${b.students}/${b.capacity}`],["Speed",`${b.speed}km/h`]].map(([k,v]) => (
                    <div key={k} style={{ background:G.card2, borderRadius:10, padding:8, textAlign:"center" }}>
                      <div style={{ fontSize:10, color:G.muted }}>{k}</div>
                      <div style={{ fontSize:13, fontWeight:700 }}>{v}</div>
                    </div>
                  ))}
                </div>
                {/* Geofence stops */}
                <div style={{ fontSize:12, color:G.muted, marginBottom:6 }}>Geofence Stops:</div>
                <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                  {route?.stops.map((s,i) => (
                    <div key={i} style={{ background: s.arrived ? G.green+"22" : G.border+"44", border:`1px solid ${s.arrived ? G.green : G.border}`, borderRadius:6, padding:"3px 8px", fontSize:11, color: s.arrived ? G.green : G.muted }}>
                      {s.arrived ? "✓" : "○"} {s.name}
                    </div>
                  ))}
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {activeTab === "students" && (
        <div style={{ padding:16 }} className="slide-up">
          <div style={{ fontFamily:G.head, fontWeight:800, fontSize:20, marginBottom:16 }}>Student Management 👥</div>
          <Input placeholder="Search by name or reg no..." value={searchQ} onChange={setSearchQ} />
          {filteredStudents.map(s => (
            <Card key={s.id} style={{ marginBottom:10 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <div>
                  <div style={{ fontWeight:700, fontSize:15 }}>{s.name}</div>
                  <div style={{ fontSize:12, color:G.muted }}>{s.regNo} · Bus {s.busId}</div>
                </div>
                <Badge label={s.feeStatus === "paid" ? "✓ Paid" : "⚠ Pending"} color={s.feeStatus === "paid" ? G.green : G.red} />
              </div>
              {s.feeStatus === "pending" && (
                <div style={{ marginTop:10, display:"flex", justifyContent:"space-between", alignItems:"center", background:G.red+"10", borderRadius:8, padding:"8px 12px" }}>
                  <span style={{ fontSize:13, color:G.red }}>Due: ₹{s.feeAmount.toLocaleString()}</span>
                  <Btn small label="Send Reminder" color={G.yellow} />
                </div>
              )}
            </Card>
          ))}
        </div>
      )}

      {activeTab === "reports" && (
        <div style={{ padding:16 }} className="slide-up">
          <div style={{ fontFamily:G.head, fontWeight:800, fontSize:20, marginBottom:16 }}>Reports & Analytics 📄</div>

          <Card style={{ marginBottom:14 }}>
            <div style={{ fontFamily:G.head, fontWeight:700, fontSize:15, marginBottom:14 }}>Fee Defaulters</div>
            {MOCK_STUDENTS.filter(s => s.feeStatus === "pending").map(s => (
              <div key={s.id} style={{ display:"flex", justifyContent:"space-between", padding:"8px 0", borderBottom:`1px solid ${G.border}` }}>
                <div>
                  <div style={{ fontSize:13, fontWeight:600 }}>{s.name}</div>
                  <div style={{ fontSize:11, color:G.muted }}>{s.regNo}</div>
                </div>
                <div style={{ color:G.red, fontWeight:700 }}>₹{s.feeAmount.toLocaleString()}</div>
              </div>
            ))}
            <div style={{ marginTop:14 }}>
              <Btn label="📥 Download PDF Report" full color={G.blue} onClick={() => {
                const content = "FEE DEFAULTERS REPORT\n" + MOCK_STUDENTS.filter(s=>s.feeStatus==="pending").map(s=>`${s.name} (${s.regNo}): ₹${s.feeAmount}`).join("\n");
                const blob = new Blob([content], { type:"text/plain" });
                const a = document.createElement("a");
                a.href = URL.createObjectURL(blob);
                a.download = "fee_defaulters.txt";
                a.click();
              }} />
            </div>
          </Card>

          <Card style={{ marginBottom:14 }}>
            <div style={{ fontFamily:G.head, fontWeight:700, fontSize:15, marginBottom:14 }}>Performance Summary</div>
            {[
              ["Total Trips", ANALYTICS.totalTrips, G.blue],
              ["On-Time", ANALYTICS.onTime, G.green],
              ["Delayed", ANALYTICS.delayed, G.yellow],
              ["Avg Delay", ANALYTICS.avgDelay, G.yellow],
            ].map(([k,v,c]) => (
              <div key={k} style={{ display:"flex", justifyContent:"space-between", padding:"8px 0", borderBottom:`1px solid ${G.border}` }}>
                <span style={{ color:G.muted, fontSize:13 }}>{k}</span>
                <span style={{ fontWeight:700, color:c }}>{v}</span>
              </div>
            ))}
          </Card>

          <Card>
            <div style={{ fontFamily:G.head, fontWeight:700, fontSize:15, marginBottom:14 }}>Geofence Alerts Today</div>
            {MOCK_NOTIFICATIONS.filter(n => n.type === "geofence").map(n => (
              <div key={n.id} style={{ display:"flex", gap:10, padding:"8px 0", borderBottom:`1px solid ${G.border}` }}>
                <span>📍</span>
                <div>
                  <div style={{ fontSize:13 }}>{n.msg}</div>
                  <div style={{ fontSize:11, color:G.muted }}>{n.time}</div>
                </div>
              </div>
            ))}
          </Card>
        </div>
      )}

      <NavBar user={user} onLogout={() => {}} activeTab={activeTab} setActiveTab={setActiveTab} tabs={tabs} />
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   ROOT APP
═══════════════════════════════════════════════════════════ */
export default function App() {
  const [user, setUser] = useState(null);

  const handleLogout = () => setUser(null);

  if (!user) return <AuthScreen onLogin={setUser} />;

  // Inject logout into nav
  const withLogout = (Dashboard) => (
    <div>
      <Dashboard user={user} />
      {/* Logout overlay on avatar already handled in NavBar */}
    </div>
  );

  return (
    <div style={{ maxWidth: 480, margin: "0 auto", background: G.bg, minHeight: "100vh", position: "relative" }}>
      <style>{css}</style>
      {/* Logout button on top-right avatar click handled inside NavBar; replicate here for correctness */}
      {user.role === "student" && <StudentDashboard user={user} onLogout={handleLogout} />}
      {user.role === "teacher" && <TeacherDashboard user={user} onLogout={handleLogout} />}
      {user.role === "driver"  && <DriverDashboard  user={user} onLogout={handleLogout} />}
      {user.role === "admin"   && <AdminDashboard   user={user} onLogout={handleLogout} />}
    </div>
  );
}
